﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Alisveris_Durum
{
    public partial class Form1 : Form
    {
        SqlCommand komut;
        SqlConnection baglanti;
        SqlDataReader oku;
        public Form1()
        {
            InitializeComponent();
        }
        public void yenile()
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Select * From tblUrun", baglanti);
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                oku = komut.ExecuteReader();
                DataTable tablo = new DataTable();
                tablo.Load(oku);
                dataGridView1.DataSource = tablo;
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close() ;
            }
        }
        public void yenile2()
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Select * From tblFirma", baglanti);
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                oku = komut.ExecuteReader();
                DataTable tablo2 = new DataTable();
                tablo2.Load(oku);
                dataGridView2.DataSource = tablo2;
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }

        public void yenile3()
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Select * From tblSatis", baglanti);
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                oku = komut.ExecuteReader();
                DataTable tablo5 = new DataTable();
                tablo5.Load(oku);
                dataGridView3.DataSource = tablo5;
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }
        private void Ekle_Click(object sender, EventArgs e)
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Insert Into tblUrun(Urun_Adi,Urun_Aciklamasi) values (@Adi, @Aciklamasi)", baglanti);
            komut.Parameters.AddWithValue("@Adi", Urun_Adi.Text);
            komut.Parameters.AddWithValue("@Aciklamasi", Urun_Aciklamasi.Text);

            try
            {
                if (baglanti.State  == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                komut.ExecuteNonQuery();
                baglanti.Close();
                yenile();
                MessageBox.Show("Başarılı Şekilde Eklendi");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Select * From tblUrun", baglanti);
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open() ;
            }
            oku = komut.ExecuteReader();
            DataTable tablo3 = new DataTable();
            tablo3.Load(oku);
            Urun_Adi_Satis.ValueMember = "Urun_Kodu";
            Urun_Adi_Satis.DisplayMember = "Urun_Adi";
            Urun_Adi_Satis.DataSource = tablo3;
            baglanti .Close();


            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Select * From tblFirma", baglanti);
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
            }
            oku = komut.ExecuteReader();
            DataTable tablo4 = new DataTable();
            tablo4.Load(oku);
            Uretici_Firma.ValueMember = "Firma_Kodu";
            Uretici_Firma.DisplayMember = "Firma_Adi";
            Uretici_Firma.DataSource = tablo4;
            baglanti.Close();
            Tarih.Text = DateTime.Now.ToShortDateString() ;
            yenile();
            yenile2();
            yenile3();
        }

        
        int Kodu = 0;
        
        private void dataGridView1_CellMouseDoubleClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
                int rowIndex = e.RowIndex;
                DataGridViewRow row = dataGridView1.Rows[rowIndex];
                Kodu = int.Parse(row.Cells[0].Value.ToString());
                Urun_Kodu = int.Parse(row.Cells[0].Value.ToString());
                Firma_Kodu = int.Parse(row.Cells[0].Value.ToString());
                baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
                komut = new SqlCommand("Select * From tblUrun where Urun_Kodu=@Kodu", baglanti);
                komut.Parameters.AddWithValue("@Kodu", Kodu);
                try
                {
                    if (baglanti.State == ConnectionState.Closed)
                    {
                        baglanti.Open();
                    }
                    oku = komut.ExecuteReader();
                    oku.Read();
                    Urun_Adi.Text = oku["Urun_Adi"].ToString();
                    Urun_Aciklamasi.Text = oku["Urun_Aciklamasi"].ToString();
                    baglanti.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    baglanti.Close();
                }
            }

            private void Guncelle_Click(object sender, EventArgs e)
            {
                baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
                komut = new SqlCommand("Update tblUrun set Urun_Adi=@Adi,Urun_Aciklamasi=@Aciklamasi where Urun_Kodu=@Kodu", baglanti);
                komut.Parameters.AddWithValue("@Kodu", Kodu);
                komut.Parameters.AddWithValue("@Adi", Urun_Adi.Text);
                komut.Parameters.AddWithValue("@Aciklamasi", Urun_Aciklamasi.Text);
                try
                {
                    if (baglanti.State == ConnectionState.Closed)
                    {
                        baglanti.Open();
                    }
                    komut.ExecuteNonQuery();
                    baglanti.Close();
                    yenile();
                    MessageBox.Show("Güncelleme Başarılı");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    baglanti.Close();
                }
            }

        private void Sil_Click(object sender, EventArgs e)
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Delete from tblUrun where Urun_Kodu=@Kodu", baglanti);
            komut.Parameters.AddWithValue("@Kodu", Kodu);
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                oku = komut.ExecuteReader();
                baglanti.Close();
                yenile();
                MessageBox.Show("Silme işlemi Başarılı");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }

        private void Ekle_Firma_Click(object sender, EventArgs e)
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Insert Into tblFirma(Firma_Adi,Firma_Adresi) values (@Adi, @Adresi)", baglanti);
            komut.Parameters.AddWithValue("@Adi", Firma_Adi.Text);
            komut.Parameters.AddWithValue("@Adresi", Firma_Adresi.Text);

            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                komut.ExecuteNonQuery();
                baglanti.Close();
                yenile2();
                MessageBox.Show("Başarılı Şekilde Eklendi");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }

        private void Guncelle_Firma_Click(object sender, EventArgs e)
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Update tblFirma set Firma_Adi=@Adi,Firma_Adresi=@Adresi where Firma_Kodu=@Kodu", baglanti);
            komut.Parameters.AddWithValue("@Kodu", Kodu);
            komut.Parameters.AddWithValue("@Adi", Firma_Adi.Text);
            komut.Parameters.AddWithValue("@Adresi", Firma_Adresi.Text);
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                komut.ExecuteNonQuery();
                baglanti.Close();
                yenile2();
                MessageBox.Show("Güncelleme Başarılı");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }

        private void Sil_Firma_Click(object sender, EventArgs e)
        {
            int kodu = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Firma_Kodu"].Value);

            string connectionString = "Data Source=KENAN;Initial Catalog=dbSatis;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("DELETE FROM tblFirma WHERE Firma_Kodu = @Kodu", connection))
                {
                    command.Parameters.AddWithValue("@Kodu", kodu);
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        yenile2();
                        MessageBox.Show("Silme işlemi başarılı.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }


        private void label4_Click(object sender, EventArgs e)
        {

        }
        int Urun_Kodu = 0;
        int Firma_Kodu = 0;
        private void Ekle_Satis_Click(object sender, EventArgs e)
        {
            baglanti = new SqlConnection("Data Source = KENAN;Initial Catalog = dbSatis; Integrated Security = True ");
            komut = new SqlCommand("Insert Into tblSatis(Urun_Kodu,Firma_Kodu,Satis_Tarihi,Fiyat,Kargo_Durum) values (@Urun_Kodu,@Firma_Kodu,@Tarih,@Fiyat,@Kargo_Durum)", baglanti);
            komut.Parameters.AddWithValue("@Urun_Kodu", Urun_Kodu);
            komut.Parameters.AddWithValue("@Firma_Kodu", Firma_Kodu);
            komut.Parameters.AddWithValue("@Tarih", Tarih.Text);
            komut.Parameters.AddWithValue("@Fiyat", Fiyat_Satis.Text);
            komut.Parameters.AddWithValue("@Kargo_Durum", Kargo_Durum.Text);

            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                }
                oku = komut.ExecuteReader();
                baglanti.Close();
                yenile3();
                MessageBox.Show("Satış Başarılı");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                baglanti.Close();
            }
        }
        int id = 0;

        private void dataGridView3_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            id = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["Satis_Kodu"].Value);
            Console.WriteLine(id.ToString());
        }

        private void Sil_button_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=KENAN;Initial Catalog=dbSatis;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("DELETE FROM tblSatis WHERE Satis_Kodu = @Kodu", connection))
                {
                    command.Parameters.AddWithValue("@Kodu", id);
                    command.ExecuteNonQuery();
                }
            }
            yenile3();
        }


    }
    }
    
